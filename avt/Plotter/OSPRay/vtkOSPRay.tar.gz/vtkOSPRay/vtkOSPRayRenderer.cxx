/* =======================================================================================
 Copyright 2014-2015 Texas Advanced Computing Center, The University of Texas at Austin
 All rights reserved.
 
 Licensed under the BSD 3-Clause License, (the "License"); you may not use this file
 except in compliance with the License.
 A copy of the License is included with this software in the file LICENSE.
 If your copy does not contain the License, you may obtain a copy of the License at:
 
 http://opensource.org/licenses/BSD-3-Clause
 
 Unless required by applicable law or agreed to in writing, software distributed under
 the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.
 See the License for the specific language governing permissions and limitations under
 limitations under the License.
 
 pvOSPRay is derived from VTK/ParaView Los Alamos National Laboratory Modules (PVLANL)
 Copyright (c) 2007, Los Alamos National Security, LLC
 ======================================================================================= */

#include <DebugStream.h>

#include "ospray/ospray.h"
#include "ospray/common/OSPCommon.h"

#include "vtkOSPRay.h"
#include "vtkOSPRayCamera.h"
#include "vtkOSPRayManager.h"
#include "vtkOSPRayRenderer.h"

#include "vtkActor.h"
#include "vtkCuller.h"
#include "vtkLight.h"
#include "vtkLightCollection.h"
#include "vtkObjectFactory.h"
#include "vtkRendererCollection.h"
#include "vtkRenderWindow.h"
#include "vtkTimerLog.h"

#include "vtkImageData.h"
#include "vtkPNGWriter.h"
#include "vtkPolyDataMapper.h"
#include "vtkPolyData.h"
// #include "vtkMultiProcessController.h"

#include <vtkSmartPointer.h>
#include <vtkCommand.h>
#include <vtkRenderer.h>
#include <vtkRendererCollection.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>


#include "vtkOSPRayActor.h"

//  VBOs
//
#if USE_VBOS
#include <GL/glu.h>
#include <assert.h>
#endif


#include <string>

vtkStandardNewMacro(vtkOSPRayRenderer);

class vtkTimerCallback : public vtkCommand
{
public:
  static vtkTimerCallback *New()
  {
    vtkTimerCallback *cb = new vtkTimerCallback;
    cb->TimerCount = 0;
    return cb;
  }
  
  virtual void Execute(vtkObject *vtkNotUsed(caller), unsigned long eventId,
                       void *vtkNotUsed(callData))
  {
    if (vtkCommand::TimerEvent == eventId)
    {
      ++this->TimerCount;
    }
    // std::cout << "timer " << this->TimerCount << std::endl;
  }
  
private:
  int TimerCount;
  
};

//----------------------------------------------------------------------------
vtkOSPRayRenderer::vtkOSPRayRenderer()
:
prog_flag(false),
Accumulate(false)
{
  debug5 << "ALOK: vtkOSPRayRenderer constructor, renderer " << this << endl;
  Frame=0;
  HasVolume= false;
  ClearAccumFlag=false;
  ComputeDepth = 0;//vtkMultiProcessController::GetGlobalController()->GetNumberOfProcesses() > 1;
  
  this->EngineInited=false;
  this->NumberOfWorkers = 1;
  this->EnableShadows = -1;
  this->Samples = 1;
  this->MaxDepth = 5;
  this->EnableVolumeShading = 0;
  
  this->ImageX = -1;
  this->ImageY = -1;
  
  this->backgroundRGB[0] = 0.0;
  this->backgroundRGB[1] = 0.0;
  this->backgroundRGB[2] = 0.0;
  AccumCounter=0;
  MaxAccum=1024;
  this->SetAmbient( 0.1, 0.1, 0.1 );
  
  this->OSPRayManager = vtkOSPRayManager::New();
  
  this->OSPRayManager->OSPRayModel = ospNewModel();
  OSPModel oModel = (OSPModel)this->OSPRayManager->OSPRayModel;
  this->OSPRayManager->OSPRayCamera = ospNewCamera("perspective");
  OSPCamera oCamera = (OSPCamera)this->OSPRayManager->OSPRayCamera;
  this->OSPRayManager->OSPRayVolumeRenderer = (osp::Renderer*)ospNewRenderer("raycast_volume_renderer");
//  this->OSPRayManager->OSPRayDynamicModel = ospNewModel();
  this->OSPRayManager->OSPRayVolumeModel = ospNewModel();
  bool ao = EnableAO;
  EnableAO=-1;
  SetEnableAO(ao);
  OSPRenderer oRenderer = (OSPRenderer)this->OSPRayManager->OSPRayRenderer;
  OSPRenderer vRenderer = (OSPRenderer)this->OSPRayManager->OSPRayVolumeRenderer;
  ospSet3f(vRenderer, "bgColor", backgroundRGB[0], backgroundRGB[1], backgroundRGB[2]);
//  OSPModel vModel = (OSPModel)this->OSPRayManager->OSPRayDynamicModel;
//  ospCommit(vModel);
//  ospSetObject(vRenderer, "dynamic_model", vModel);
  OSPModel vModel = (OSPModel)this->OSPRayManager->OSPRayVolumeModel;
  SetEnableShadows(0);
  
  ospSetObject(vRenderer,"world",vModel);
  ospSetObject(vRenderer,"model",vModel);
  ospSetObject(vRenderer,"camera",oCamera);
  ospCommit(vRenderer);
  
  Assert(oRenderer != NULL && "could not create renderer");
  Assert(vRenderer != NULL && "could not create renderer");
  
  ospSetObject(oRenderer,"world",oModel);
  ospSetObject(oRenderer,"model",oModel);
  ospSetObject(oRenderer,"camera",oCamera);
  ospSet1i(oRenderer,"spp",Samples);
  ospSet3f(oRenderer,"bgColor",1,1,1);
  ospCommit(oModel);
  ospCommit(oCamera);
  ospCommit(oRenderer);
  
  this->ColorBuffer = NULL;
  this->DepthBuffer = NULL;
  this->osp_framebuffer = NULL;
}

//----------------------------------------------------------------------------
vtkOSPRayRenderer::~vtkOSPRayRenderer()
{
  if (this->osp_framebuffer)
  {
    ospFreeFrameBuffer(this->osp_framebuffer);
    this->osp_framebuffer = NULL;
  }
  
  if (this->ColorBuffer)
  {
    delete[] this->ColorBuffer;
    this->ColorBuffer = NULL;
  }
  
  if (this->DepthBuffer)
  {
    delete[] this->DepthBuffer;
    this->DepthBuffer = NULL;
  }
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::InitEngine()
{
  this->EngineInited = true;
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::SetBackground(double r, double g, double b)
{
  OSPRenderer oRenderer = (OSPRenderer)this->OSPRayManager->OSPRayRenderer;
  OSPRenderer vRenderer = (OSPRenderer)this->OSPRayManager->OSPRayVolumeRenderer;
  ospSet3f(oRenderer,"bgColor",r,g,b);
  ospSet3f(vRenderer,"bgColor",r,g,b);
  
  backgroundRGB[0] = r;
  backgroundRGB[1] = g;
  backgroundRGB[2] = b;
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::ClearLights(void)
{
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::Clear()
{
}
//----------------------------------------------------------------------------
void vtkOSPRayRenderer::ClearAccumulation()
{
  if (osp_framebuffer)
    ospFrameBufferClear(osp_framebuffer, OSP_FB_ACCUM);
  AccumCounter=0;
  
}


//----------------------------------------------------------------------------
// Ask lights to load themselves into graphics pipeline.
int vtkOSPRayRenderer::UpdateLights()
{
  
  OSPRenderer renderer = ((OSPRenderer)this->OSPRayManager->OSPRayRenderer);
  OSPRenderer vRenderer = ((OSPRenderer)this->OSPRayManager->OSPRayVolumeRenderer);
  std::vector<OSPLight> lights;
  
  
  // convert VTK lights into OSPRay lights
  vtkCollectionSimpleIterator sit;
  this->Lights->InitTraversal( sit );
  
  vtkLight *vLight = NULL;
  bool noneOn = true;
  for ( this->Lights->InitTraversal( sit );
       ( vLight = this->Lights->GetNextLight( sit ) ) ; )
  {
    if ( vLight->GetSwitch() )
    {
      noneOn = false;
    }
    vtkLight* light = vLight;
    
    double *color, *position, *focal, direction[3];
    
    // OSPRay Lights only have one "color"
    color    = light->GetDiffuseColor();
    position = light->GetTransformedPosition();
    focal    = light->GetTransformedFocalPoint();
    
    if (light->GetPositional())
    {
      OSPLight ospLight = ospNewLight(renderer, "OBJPointLight");
      ospSetString(ospLight, "name", "point" );
      ospSet3f(ospLight, "color", color[0],color[1],color[2]);
      ospSet3f(ospLight, "position", position[0],position[1],position[2]);
      ospCommit(ospLight);
      lights.push_back(ospLight);
    }
    else
    {
      direction[0] = position[0] - focal[0];
      direction[1] = position[1] - focal[1];
      direction[2] = position[2] - focal[2];
      OSPLight ospLight = ospNewLight(renderer, "DirectionalLight");
      ospSetString(ospLight, "name", "directional" );
      float scale = 0.8;
      ospSet3f(ospLight, "color", color[0]*scale,color[1]*scale,color[2]*scale);
      osp::vec3f dir(-direction[0],-direction[1],-direction[2]);
      dir = normalize(dir);
      ospSet3f(ospLight, "direction", dir.x,dir.y,dir.z);
      ospCommit(ospLight);
      lights.push_back(ospLight);
    }
    
    if (noneOn)
    {
      {
        cerr
        << "No light defined, creating a headlight at camera position" << endl;
      }
    }
    else
    {
    }
  }
  {
    
  }
  {
  }
  
  OSPData lightsArray = ospNewData(lights.size(), OSP_OBJECT, &lights[0], 0);
  ospSetData(renderer, "lights",lightsArray);
  ospSetData(vRenderer, "lights",lightsArray);
  ospCommit(renderer);
  
  
  
  return 0;
}

//----------------------------------------------------------------------------
vtkCamera* vtkOSPRayRenderer::MakeCamera()
{
  return vtkOSPRayCamera::New();
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::UpdateSize()
{
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::DeviceRender()
{
  std::cerr << __PRETTY_FUNCTION__ << " " << __LINE__ << std::endl;
  debug5 << "ALOK: vtkOSPRayRenderer::DeviceRender(), renderer " << this 
      << endl;
  renderables.clear();
  if ((! prog_flag) || ClearAccumFlag)
  {
    if (osp_framebuffer)
      ospFrameBufferClear(osp_framebuffer, OSP_FB_COLOR | (ComputeDepth ? OSP_FB_DEPTH : 0) | OSP_FB_ACCUM);
    AccumCounter=0;
    ClearAccumFlag=false;
  }
  else
    prog_flag = false;
  
  if (this->GetLayer() != 0 && this->GetActors()->GetNumberOfItems() == 0)
  {
    return;
  }
  
  vtkTimerLog::MarkStartEvent("OSPRay Dev Render");
  
  if (!this->EngineInited )
  {
    this->InitEngine();
  }
  
  vtkTimerLog::MarkStartEvent("Geometry");
  
  this->Clear();
  
  this->UpdateSize();
  
  
  HasVolume = false;
  OSPRenderer oRenderer = (OSPRenderer)this->OSPRayManager->OSPRayRenderer;
  this->OSPRayManager->OSPRayModel = ospNewModel();
  OSPModel oModel = (OSPModel)this->OSPRayManager->OSPRayModel;
  OSPCamera oCamera = (OSPCamera)this->OSPRayManager->OSPRayCamera;
  ospSetObject(oRenderer,"world",oModel);
  ospSetObject(oRenderer,"model",oModel);
  ospSetObject(oRenderer,"camera",oCamera);
  
  
  ospCommit(this->OSPRayManager->OSPRayModel);
  ospCommit(this->OSPRayManager->OSPRayRenderer);
  
  this->UpdateCamera();
  
  
  this->UpdateLightGeometry();
  this->UpdateLights();
  
  //Clear all actors
//  vtkActorCollection *actorList = this->GetActors();
//  actorList->InitTraversal();
//  for(int i=0; i<actorList->GetNumberOfItems(); i++) {
//    vtkActor *a = actorList->GetNextActor();
//    vtkOSPRayActor *OSPRayActor = vtkOSPRayActor::SafeDownCast(a);
//    if (OSPRayActor)
//      OSPRayActor->PreRender();
//  }
  
  this->UpdateGeometry();
  
  vtkTimerLog::MarkEndEvent("Geometry");
  
  vtkTimerLog::MarkStartEvent("Total LayerRender");
  this->LayerRender();
  
  vtkTimerLog::MarkEndEvent("Total LayerRender");
  
  vtkTimerLog::MarkEndEvent("OSPRay Dev Render");
  Frame++;
}

//----------------------------------------------------------------------------
// let the renderer display itself appropriately based on its layer index
void vtkOSPRayRenderer::LayerRender()
{
  std::cerr << __PRETTY_FUNCTION__ << " " << __LINE__ << std::endl;
  int     i, j;
  int     rowLength,  OSPRaySize[2];
  int     minWidth,   minHeight;
  int     hOSPRayDiff, hRenderDiff;
  int     renderPos[2];
  int*    renderSize  = NULL;
  int*    renWinSize  = NULL;
  bool    stereoDumy;
  float*  OSPRayBuffer = NULL;
  double* renViewport = NULL;
  
  // collect some useful info
  renderSize = this->GetSize();
  renWinSize = this->GetRenderWindow()->GetActualSize();
  renViewport= this->GetViewport();
  renderPos[0] = int( renViewport[0] * renWinSize[0] + 0.5f );
  renderPos[1] = int( renViewport[1] * renWinSize[1] + 0.5f );
  minWidth = renderSize[0];
  minHeight =renderSize[1];
  hOSPRayDiff = 0;
  hRenderDiff = 0;
  // memory allocation and acess to the OSPRay image
  int size = renderSize[0]*renderSize[1];
  if (this->ImageX != renderSize[0] || this->ImageY != renderSize[1])
  {
    this->ImageX = renderSize[0];
    this->ImageY = renderSize[1];
    
    if (this->ColorBuffer) delete[] this->ColorBuffer;
    this->ColorBuffer = new float[ size ];
    
    if (this->DepthBuffer) delete[] this->DepthBuffer;
    this->DepthBuffer = new float[ size ];
    
    if (this->osp_framebuffer) ospFreeFrameBuffer(this->osp_framebuffer);
    this->osp_framebuffer = ospNewFrameBuffer(osp::vec2i(renderSize[0], renderSize[1]), OSP_RGBA_I8, OSP_FB_COLOR | (ComputeDepth ? OSP_FB_DEPTH : 0) | OSP_FB_ACCUM);
    ospFrameBufferClear(osp_framebuffer, OSP_FB_ACCUM);
    AccumCounter=0;
    this->UpdateCamera();
  }
    //TODO: save framebuffer
  // mantaBuffer = static_cast< float * >( mantaBase->getRawData(0) );

  // update this->ColorBuffer and this->DepthBuffer from the Manta
  // RGBA8ZfloatPixel array
  double *clipValues = this->GetActiveCamera()->GetClippingRange();
  double depthScale  = 1.0f / ( clipValues[1] - clipValues[0] );

  //
  //  OSPRay
  //
  // printf("ospRender\n");
  //OSPRenderer renderer = ((OSPRenderer)this->OSPRayManager->OSPRayRenderer);
  OSPRenderer renderer = ((OSPRenderer)this->OSPRayManager->OSPRayVolumeRenderer);
  // std::cout << "renderer: " << this->OSPRayManager->ospRenderer << std::endl;
  // PRINT(renderer);
  // OSPFramebuffer framebuffer = this->OSPRayManager->ospFramebuffer;
  OSPModel ospModel = ((OSPModel)this->OSPRayManager->OSPRayModel);
  // PRINT(ospModel);
  ospCommit(ospModel);

              //TODO: Need to figure out where we're going to read lighting data from
    //begin light test
    std::vector<OSPLight> pointLights;
    // cout << "msgView: Adding a hard coded directional light as the sun." << endl;
    OSPLight ospLight = ospNewLight(renderer, "DirectionalLight");
    ospSetString(ospLight, "name", "sun" );
    ospSet3f(ospLight, "color", .6, .6, .55);
    ospSet3f(ospLight, "direction", -1, -1, 0);
    ospCommit(ospLight);
    pointLights.push_back(ospLight);
    OSPLight ospLight2 = ospNewLight(renderer, "DirectionalLight");
    ospSetString(ospLight2, "name", "shadow" );
    ospSet3f(ospLight2, "color", .3, .35, .4);
    ospSet3f(ospLight2, "direction", 1, .5, 0);
    ospCommit(ospLight2);
    pointLights.push_back(ospLight);
    OSPData pointLightArray = ospNewData(pointLights.size(), OSP_OBJECT, &pointLights[0], 0);
    ospSetData(renderer, "directionalLights", pointLightArray);
// updateCamera();
  ospCommit(renderer);
  ospCommit(ospModel);
    //end light test

  // printf("render\n");


ospRenderFrame(this->osp_framebuffer,renderer);
  // ospRenderFrame(framebuffer,renderer);

  float* ospBuffer = (float *) ospMapFrameBuffer(osp_framebuffer);

       // this->OSPRayManager->ospModel = ospNewModel();
      // ospSetParam(renderer,"world",this->OSPRayManager->ospModel);
  // ospSetParam(renderer,"model",this->OSPRayManager->ospModel);

  // ospCommit(renderer);

  vtkTimerLog::MarkStartEvent("Image Conversion");

  for ( j = 0; j < minHeight; j ++ )
    {
    // there are two floats in each pixel in Manta buffer
    // int mantaIndex = ( ( j + hMantaDiff  ) * rowLength     ) * 2;
    // there is only one float in each pixel in the GL RGBA or Z buffer
    int tupleIndex = ( ( j + hRenderDiff ) * renderSize[0] ) * 1;

    for ( i = 0; i < minWidth; i ++ )
      {
      // this->ColorBuffer[ tupleIndex + i ]
                         // = mantaBuffer[ mantaIndex + i*2     ];
                         #if USE_OSPRAY
      this->ColorBuffer[ tupleIndex + i ]
                         = ospBuffer[ tupleIndex + i  ];
                         // char testBuff[] = {128,128,255,255};
                         // this->ColorBuffer[ tupleIndex + i ]
                         // = *((float*)testBuff);
                         #endif
      // float depthValue   = mantaBuffer[ mantaIndex + i*2 + 1 ];
                         float depthValue = 100; //TODO Carson: HACK
      // normalize the depth values to [ 0.0f, 1.0f ], since we are using a
      // software buffer for Z values and never write them to OpenGL buffers,
      // we don't have to clamp them any more
      // TODO: On a second thought, we probably don't even have to normalize Z
      // values at all
      this->DepthBuffer[ tupleIndex + i ]
                         = ( depthValue - clipValues[0] ) * depthScale;
      }
    }

#if 0
  // let layer #0 initialize GL depth buffer
  if ( this->GetLayer() == 0 )
    {
    // this->GetRenderWindow()->
    //   SetZbufferData( renderPos0[0],  renderPos0[1],
    //                   renderPos0[0] + renderSize[0] - 1,
    //                   renderPos0[1] + renderSize[1] - 1,
    //                   this->DepthBuffer );

    this->GetRenderWindow()->
      SetRGBACharPixelData( renderPos0[0],  renderPos0[1],
                            renderPos0[0] + renderSize[0] - 1,
                            renderPos0[1] + renderSize[1] - 1,
                            (unsigned char*)this->ColorBuffer, 0, 0 );
    glFinish();
    }
  else
    {
    //layers on top add the colors of their non background pixels
    unsigned char*  GLbakBuffer = NULL;
    GLbakBuffer = this->GetRenderWindow()->
      GetRGBACharPixelData( renderPos0[0],  renderPos0[1],
                            renderPos0[0] + renderSize[0] - 1,
                            renderPos0[1] + renderSize[1] - 1, 0 );

    bool anyhit = false;
    unsigned char *optr = GLbakBuffer;
    unsigned char *iptr = (unsigned char*)this->ColorBuffer;
    float *zptr = this->DepthBuffer;
    for ( j = 0; j < renderSize[1]; j++)
    {
      for ( i = 0; i < renderSize[0]; i++)
        {
        const float z = *zptr;
        if (z > 0 && z < 1.0)
          {
          anyhit = true;
          *(optr+0) = *(iptr+0);
          *(optr+1) = *(iptr+1);
          *(optr+2) = *(iptr+2);
          *(optr+3) = *(iptr+3);
          }
        optr+=4;
        iptr+=4;
        zptr++;
        }
    }

    if (anyhit)
      {
      // submit the modified RGB colors to GL BACK buffer
      this->GetRenderWindow()->
        SetRGBACharPixelData( renderPos0[0],  renderPos0[1],
          renderPos0[0] + renderSize[0] - 1,
          renderPos0[1] + renderSize[1] - 1,
          GLbakBuffer, 0, 0 );
      }

    delete [] GLbakBuffer;
    }
    #endif

      if ( this->GetLayer() == 1 )
  {
    //memcpy(this->ColorBuffer, mms->ColorBufferStatic, sizeof(float)*xmin*ymin);
    this->GetRenderWindow()->
      SetZbufferData( renderPos[0],  renderPos[1],
          renderPos[0] + renderSize[0] - 1,
          renderPos[1] + renderSize[1] - 1,
          this->DepthBuffer );

    //printf("renderPos: %d %d renderSize: %d %d colorbuffersize: %d\n", renderPos0[0], renderPos0[1],
    //    renderSize[0], renderSize[1], int(size));
    this->GetRenderWindow()->
      SetRGBACharPixelData( renderPos[0],  renderPos[1],
          renderPos[0] + renderSize[0] - 1,
          renderPos[1] + renderSize[1] - 1,
          (unsigned char*)this->ColorBuffer, 0, 0 );

    //glFinish();
  }
  else
  {
    //layers on top add the colors of their non background pixels
    unsigned char*  GLbakBuffer = NULL;
    GLbakBuffer = this->GetRenderWindow()->
      GetRGBACharPixelData( renderPos[0],  renderPos[1],
          renderPos[0] + renderSize[0] - 1,
          renderPos[1] + renderSize[1] - 1, 0 );

    bool anyhit = false;
    unsigned char *optr = GLbakBuffer;
    unsigned char *iptr = (unsigned char*)this->ColorBuffer;
    float *zptr = this->DepthBuffer;
    for ( j = 0; j < renderSize[1]; j++)
    {
      for ( i = 0; i < renderSize[0]; i++)
      {
        const float z = *zptr;
        if (z > 0 && z < 1.0)
        {
          anyhit = true;
          *(optr+0) = *(iptr+0);
          *(optr+1) = *(iptr+1);
          *(optr+2) = *(iptr+2);
          *(optr+3) = *(iptr+3);
        }
        optr+=4;
        iptr+=4;
        zptr++;
      }
    }

    if (1)//anyhit)
    {
      // submit the modified RGB colors to GL BACK buffer
      this->GetRenderWindow()->
        SetRGBACharPixelData( renderPos[0],  renderPos[1],
            renderPos[0] + renderSize[0] - 1,
            renderPos[1] + renderSize[1] - 1,
            GLbakBuffer, 0, 0 );
    }

    delete [] GLbakBuffer;
  }

    //
    // ospray
    //
    ospUnmapFrameBuffer(ospBuffer, osp_framebuffer);
    // this->OSPRayManager->ospModel = ospNewModel();
    // ospSetParam(renderer,"world",this->OSPRayManager->ospModel);
    // ospSetParam(renderer,"model",this->OSPRayManager->ospModel);

    // ospCommit(renderer);
  //
  // - ospray
  //

  //cerr << "MR(" << this << ") release" << endl;
  vtkTimerLog::MarkEndEvent("Image Conversion");

}
#if 0
//----------------------------------------------------------------------------
// let the renderer display itself appropriately based on its layer index
void vtkOSPRayRenderer::LayerRender()
{
  std::cerr << __PRETTY_FUNCTION__ << " " << __LINE__ << std::endl;
  int     i, j;
  int     rowLength,  OSPRaySize[2];
  int     minWidth,   minHeight;
  int     hOSPRayDiff, hRenderDiff;
  int     renderPos[2];
  int*    renderSize  = NULL;
  int*    renWinSize  = NULL;
  bool    stereoDumy;
  float*  OSPRayBuffer = NULL;
  double* renViewport = NULL;
  
  // collect some useful info
  renderSize = this->GetSize();
  renWinSize = this->GetRenderWindow()->GetActualSize();
  renViewport= this->GetViewport();
  renderPos[0] = int( renViewport[0] * renWinSize[0] + 0.5f );
  renderPos[1] = int( renViewport[1] * renWinSize[1] + 0.5f );
  minWidth = renderSize[0];
  minHeight =renderSize[1];
  hOSPRayDiff = 0;
  hRenderDiff = 0;
  // memory allocation and acess to the OSPRay image
  int size = renderSize[0]*renderSize[1];
  if (this->ImageX != renderSize[0] || this->ImageY != renderSize[1])
  {
    this->ImageX = renderSize[0];
    this->ImageY = renderSize[1];
    
    if (this->ColorBuffer) delete[] this->ColorBuffer;
    this->ColorBuffer = new float[ size ];
    
    if (this->DepthBuffer) delete[] this->DepthBuffer;
    this->DepthBuffer = new float[ size ];
    
    if (this->osp_framebuffer) ospFreeFrameBuffer(this->osp_framebuffer);
    this->osp_framebuffer = ospNewFrameBuffer(osp::vec2i(renderSize[0], renderSize[1]), OSP_RGBA_I8, OSP_FB_COLOR | (ComputeDepth ? OSP_FB_DEPTH : 0) | OSP_FB_ACCUM);
    ospFrameBufferClear(osp_framebuffer, OSP_FB_ACCUM);
    AccumCounter=0;
    this->UpdateCamera();
  }
  if (HasVolume)
  {
    OSPRenderer vRenderer = (OSPRenderer)this->OSPRayManager->OSPRayVolumeRenderer;
//    OSPModel vdModel = (OSPModel)this->OSPRayManager->OSPRayDynamicModel;
//    ospSetObject(vRenderer, "dynamic_model", vdModel);
    OSPModel vModel = (OSPModel)this->OSPRayManager->OSPRayVolumeModel;
    OSPCamera oCamera = (OSPCamera)this->OSPRayManager->OSPRayCamera;

    for(int i=0;i<renderables.size();i++)
      ospAddGeometry((OSPModel)this->OSPRayManager->OSPRayVolumeModel,renderables[i]->instance);
    
    ospSetObject(vRenderer,"world",vModel);
//    ospSetObject(vRenderer,"dynamic_model",vdModel);
    ospSetObject(vRenderer,"model",vModel);
    ospSetObject(vRenderer,"camera",oCamera);
    
    ospCommit(vModel);
//    ospCommit(vdModel);
    ospCommit(vRenderer);
    
    
    ospRenderFrame(this->osp_framebuffer,vRenderer,OSP_FB_COLOR|OSP_FB_ACCUM);
    AccumCounter++;
  }
  else
  {
    OSPRenderer renderer = ((OSPRenderer)this->OSPRayManager->OSPRayRenderer);
    OSPModel ospModel = ((OSPModel)this->OSPRayManager->OSPRayModel);
    
    ospCommit(renderer);
    ospCommit(ospModel);
    
    ospRenderFrame(this->osp_framebuffer,renderer,OSP_FB_COLOR|OSP_FB_ACCUM);
    AccumCounter++;
  }
  
  //
  // Copy Depth Buffer
  //
  if (ComputeDepth)
  {
    double *clipValues = this->GetActiveCamera()->GetClippingRange();
    double viewAngle = this->GetActiveCamera()->GetViewAngle();
    
    // Closest point is center of near clipping plane - farthest is
    // corner of far clipping plane
    double clipMin = clipValues[0];
    double clipMax = clipValues[1] / pow(cos(viewAngle / 2.0), 2.0);
    double clipDiv = 1.0 / (clipMax - clipMin);
    
    const void *b = ospMapFrameBuffer(this->osp_framebuffer, OSP_FB_DEPTH);
    
    float *s = (float *)b;
    float *d = this->DepthBuffer;
    for (int i = 0; i < size; i++, s++, d++)
      *d = isinf(*s) ? 1.0 : (*s - clipMin) * clipDiv;
    
    ospUnmapFrameBuffer(b, this->osp_framebuffer);
    
    this->GetRenderWindow()->MakeCurrent();
    glDepthFunc(GL_ALWAYS);
    
    this->GetRenderWindow()->SetZbufferData(renderPos[0], renderPos[1],
                                            renderPos[0] + renderSize[0] - 1, renderPos[1] + renderSize[1] - 1, this->DepthBuffer);
  }
  //
  // Copy RGBA Buffer
  //
  
  const void* rgba = ospMapFrameBuffer(this->osp_framebuffer);
  memcpy((void *)this->ColorBuffer, rgba, size*sizeof(float));
  ospUnmapFrameBuffer(rgba, this->osp_framebuffer);


  std::cerr << __PRETTY_FUNCTION__ << " " << __LINE__ << std::endl;
  
  
  vtkTimerLog::MarkStartEvent("Image Conversion");
  
  // let layer #0 initialize GL depth buffer
  if ( this->GetLayer() == 0 )
  {
    this->GetRenderWindow()->
    SetRGBACharPixelData( renderPos[0],  renderPos[1],
                         renderPos[0] + renderSize[0] - 1,
                         renderPos[1] + renderSize[1] - 1,
                         (unsigned char*)this->ColorBuffer, 0, 0 );
    glFinish();
  }
  else
  {
    //layers on top add the colors of their non background pixels
    unsigned char*  GLbakBuffer = NULL;
    GLbakBuffer = this->GetRenderWindow()->
    GetRGBACharPixelData( renderPos[0],  renderPos[1],
                         renderPos[0] + renderSize[0] - 1,
                         renderPos[1] + renderSize[1] - 1, 0 );
    
    bool anyhit = false;
    unsigned char *optr = GLbakBuffer;
    unsigned char *iptr = (unsigned char*)this->ColorBuffer;
    float *zptr = this->DepthBuffer;
    for ( j = 0; j < renderSize[1]; j++)
    {
      for ( i = 0; i < renderSize[0]; i++)
      {
        const float z = *zptr;
        if (z > 0 && z < 1.0)
        {
          anyhit = true;
          *(optr+0) = *(iptr+0);
          *(optr+1) = *(iptr+1);
          *(optr+2) = *(iptr+2);
          *(optr+3) = *(iptr+3);
        }
        optr+=4;
        iptr+=4;
        zptr++;
      }
    }
    
    if (anyhit)
    {
      // submit the modified RGB colors to GL BACK buffer
      this->GetRenderWindow()->
      SetRGBACharPixelData( renderPos[0],  renderPos[1],
                           renderPos[0] + renderSize[0] - 1,
                           renderPos[1] + renderSize[1] - 1,
                           GLbakBuffer, 0, 0 );
    }
    
    delete [] GLbakBuffer;
  }
  
  vtkTimerLog::MarkEndEvent("Image Conversion");
}
#endif

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::PrintSelf( ostream& os, vtkIndent indent )
{
  this->Superclass::PrintSelf( os, indent );
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::SetNumberOfWorkers( int newval )
{
  if (this->NumberOfWorkers == newval)
  {
    return;
  }
}

void vtkOSPRayRenderer::AddOSPRayRenderable(vtkOSPRayRenderable* inst)
{
  ospAddGeometry((OSPModel)this->OSPRayManager->OSPRayModel,inst->instance);
  renderables.push_back(inst);
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::SetEnableShadows( int newval )
{
  if (this->EnableShadows == newval)
  {
    return;
  }
  this->EnableShadows = newval;
  
  OSPRenderer renderer = ((OSPRenderer)this->OSPRayManager->OSPRayRenderer);
  ospSet1i(renderer,"shadowsEnabled", this->EnableShadows);
  ospCommit(renderer);
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::SetSamples( int newval )
{
  if (this->Samples == newval || newval < 1)
  {
    return;
  }
  
  this->Samples = newval;
  
  
  OSPRenderer renderer = ((OSPRenderer)this->OSPRayManager->OSPRayRenderer);
  
  Assert(renderer);
  
  ospSet1i(renderer,"spp",Samples);
  ospCommit(renderer);
  
  OSPRenderer vRenderer = ((OSPRenderer)this->OSPRayManager->OSPRayVolumeRenderer);
  
  Assert(vRenderer);
  
  ospSet1i(vRenderer,"spp",Samples);
  ospCommit(vRenderer);
  
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::SetEnableAO( int newval )
{
  if (this->EnableAO == newval)
  {
    return;
  }
  
  this->EnableAO = newval;
  
  UpdateOSPRayRenderer();
  
}

void vtkOSPRayRenderer::SetEnableVolumeShading( int newval )
{
  EnableVolumeShading = newval;
}

void vtkOSPRayRenderer::UpdateOSPRayRenderer()
{
  OSPModel oModel = (OSPModel)this->OSPRayManager->OSPRayModel;
  OSPCamera oCamera = (OSPCamera)this->OSPRayManager->OSPRayCamera;
  
  if (EnableAO != 0)
  {
    this->OSPRayManager->OSPRayRenderer = (osp::Renderer*)ospNewRenderer("ao4");
  }
  else
  {
    // this->OSPRayManager->OSPRayRenderer = (osp::Renderer*)ospNewRenderer("obj");
    // this->OSPRayManager->OSPRayRenderer = (osp::Renderer*)ospNewRenderer("raycast_volume_renderer");
    this->OSPRayManager->OSPRayRenderer = this->OSPRayManager->OSPRayVolumeRenderer;
  }
  OSPRenderer oRenderer = (OSPRenderer)this->OSPRayManager->OSPRayRenderer;
  
  Assert(oRenderer != NULL && "could not create renderer");
  
  ospSetObject(oRenderer,"dynamic_model",ospNewModel());
  ospSetObject(oRenderer,"world",oModel);
  ospSetObject(oRenderer,"model",oModel);
  ospSetObject(oRenderer,"camera",oCamera);
  ospCommit(oRenderer);
  
  ospSet1i(oRenderer,"spp",Samples);
  ospSet1f(oRenderer,"epsilon", 10e-2);
  ospSet1i(oRenderer,"shadowsEnabled", this->EnableShadows);
  
  ospCommit(oRenderer);
  SetBackground(backgroundRGB[0],backgroundRGB[1],backgroundRGB[2]);
  
  vtkActorCollection *actorList = this->GetActors();
  actorList->InitTraversal();
  
  int numActors = actorList->GetNumberOfItems();
  for(int i=0; i<numActors; i++) {
    vtkActor *a = actorList->GetNextActor();
    a->Modified();
  }
}

//----------------------------------------------------------------------------
void vtkOSPRayRenderer::SetMaxDepth( int newval )
{
  if (this->MaxDepth == newval)
  {
    return;
  }
  
  this->MaxDepth = newval;
}
